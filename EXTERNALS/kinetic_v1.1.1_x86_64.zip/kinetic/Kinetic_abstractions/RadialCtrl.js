/*

2d vector control

arguments: fgred fggreen fgblue bgred bggreen bbgblue radius
Copyright (C) 2009 - 2017 - INESC Porto, George Sioros

*/

inlets = 2;
outlets = 3;
sketch.default2d(); //like default3d but uses orthographic projection

var vbrgb = [0.67, 0.70, 0.72, 1.];
var vfrgb = [0.35, 0.35, 0.35, 1.];
var vcrgb = [0.9, 0.9, 0.9, 1];
var w = [0,0,0];
var vx = 0;
var vy = 0;
var pR = 0;
var pT = 0;
var autoColor = true;
autowatch = 1;

// process arguments
if (jsarguments.length>1)
    vfrgb[0] = jsarguments[1]/255.;
if (jsarguments.length>2)
    vfrgb[1] = jsarguments[2]/255.;
if (jsarguments.length>3)
    vfrgb[2] = jsarguments[3]/255.;
if (jsarguments.length>4)
    vfrgb[3] = jsarguments[4]/255.;
if (jsarguments.length>5)
    vbrgb[0] = jsarguments[5]/255.;
if (jsarguments.length>6)
    vbrgb[1] = jsarguments[6]/255.;
if (jsarguments.length>7)
    vbrgb[2] = jsarguments[7]/255.;
if (jsarguments.length>8)
    vbrgb[3] = jsarguments[8]/255.;




draw();

function draw()
{
    var str;
    var w_ar = [0,0,0];
    w_ar[0] = w[0]*0.95;
    w_ar[1] = w[1]*0.95;
    w_ar[2] = w[2]*0.95;
    with (sketch) {
       // glclearcolor(0.67, 0.70, 0.72, 1.);            
        glclearcolor(vbrgb); 
		glclear();
        gllinewidth(2);
        moveto(0.,0.,0.);
        glcolor([0, 0, 0, 0.3]);
        circle(0.95);
        glcolor(vcrgb);
        framecircle (0.95);
        glcolor(vfrgb);
        lineto (w_ar);
        glcolor (vfrgb);
    //    moveto(w);
        circle(0.05);


    }
}

function msg_float(v)
{
    var i = inlet;
    
    if (i==0)
        setPolarCoordinates(v,360. * pT/(Math.PI * 2.));
    else
        setPolarCoordinates(pR*2.,v);
    bang();
}

function set(v)
{
    var i = inlet;
    
    if (i==0)
        setPolarCoordinates(v,360. * pT/(Math.PI * 2.));
    else
        setPolarCoordinates(pR*2.,v);
    draw();
    refresh();
}

function list()
{   
    if (arguments.length>1)
        setPolarCoordinates(arguments[0], arguments[1]);
    bang();
}


function bang()
{
    draw();
    refresh();
    var theta = pT*360/(Math.PI*2.);
    var R = 2*pR;
    outlet(1,theta);
    outlet(0,R);
}

function fsaa(v)
{
    sketch.fsaa = v;
    bang();
}

function frgb(r,g,b,a)
{
    vfrgb[0] = r/255.;
    vfrgb[1] = g/255.;
    vfrgb[2] = b/255.;
    vfrgb[3] = a/255.;
    draw();
    refresh();
}

function brgb(r,g,b,a)
{
    vbrgb[0] = r/255.;
    vbrgb[1] = g/255.;
    vbrgb[2] = b/255.;
    vbrgb[3] = a/255.;
    //set the rest of the colors to contrast the bg
    if (autoColor)
    {
        var tempSum = 0.75*(r+g+b)/3.;
        var tempF;
        if (tempSum<0.5)
        {
            tempF = 0.2;
            vfrgb[0] = 220;
            vfrgb[1] = 220;
            vfrgb[2] = 220;

        } else
        {
            tempF = 5;
            vfrgb[0] = 20;
            vfrgb[1] = 20;
            vfrgb[2] = 20;
        }
        crgb [0] = tempF * vbrgb[0];
        crgb [1] = tempF * vbrgb[1];
        crgb [2] = tempF * vbrgb[2];
    }
    draw();
    refresh();
}

function crgb(r,g,b,a)
{
	vcrgb[0] = r/255.;
    vcrgb[1] = g/255.;
    vcrgb[2] = b/255.;
    vcrgb[3] = a/255.;
    draw();
    refresh();
}

function autoColor (v)
{
    if (v!=0)
        autoColor = true;
    else if (v==0)
        autoColor = false;
}


function setvalueof(x,y)
{
    list(x,y);
}

function getvalueof()
{
    var a = new Array(vx,vy);
    
    return a;
}

function onresize(w,h)
{
    draw();
    refresh();
}
onresize.local = 1; //private

function onclick(x,y)
{
//    var width = box.rect[2] - box.rect[0];
//    var height = box.rect[3] - box.rect[1]
//    var relX = x/width;
//    var relY = 1- y/height;
//    var cX = relX-0.5;
//    var cY = relY-0.5;
//    var Radious = Math.sqrt(cX*cX + cY*cY);
//    if (Radious<=.5)
//        {
            ondrag(x,y);
//        }
}
onclick.local = 1; //private

function ondrag(x,y)
{

    var width = box.rect[2] - box.rect[0];
    var height = box.rect[3] - box.rect[1];
//    if (x<0) x = 0;
//    else if (x>width) x = width;
//    if (y<0) y = 0;
//    else if (y>height) y = height;
    vx = x/width;
    vy = 1- y/height;
    var cX = vx-0.5;
    var cY = vy-0.5;
    var Radious = Math.sqrt(cX*cX + cY*cY);
    if (Radious>0.55) return;
    refreshPolar();
    if (pR>0.5)
    {
        pR = 0.5;
        vx = 0.5 + pR*Math.cos(pT);
        vy = 0.5 + pR*Math.sin(pT);
        x = width*vx;
        y = (1-vy)*height;
    }
    w = sketch.screentoworld(x,y);
    notifyclients();
    bang();
}
ondrag.local = 1; //private

function refreshPolar()
{
    var cX = vx-0.5;
    var cY = vy-0.5;
    pR = Math.sqrt(cX*cX + cY*cY);
    pT = Math.atan2(cY, cX);
    if (pT<0.)
        pT = pT + 2*Math.PI;
    
}

refreshPolar.local = 1;//private

function setPolarCoordinates (r, a)
{
    var width = box.rect[2] - box.rect[0];
    var height = box.rect[3] - box.rect[1];
    var tR = pR;
    var tT = 360. * pT/(Math.PI * 2.);
    tR = r*0.5;
    tT = a;
    if (tR<0.)
        tR = 0.;
    else if (tR>0.5)
        tR = 0.5; 
    pT = (tT % 360)*Math.PI*2./360.;
    pR = tR;
    vx = 0.5 + pR*Math.cos(pT);
    vy = 0.5 + pR*Math.sin(pT);
    if (vx<0) vx = 0;
    else if (vx>1) vx = 1;
    if (vy<0) vy = 0;
    else if (vy>1) vy = 1;
    
    w = sketch.screentoworld(vx*width,(1.-vy)*height);
    notifyclients();
}
setPolarCoordinates.local = 1;

function getBGcolor()
{
	var tempvector = this.patcher.getattr ("locked_bgcolor");
	if (autoColor)
	{
		brgb(tempvector[0]*255.,tempvector[1]*255.,tempvector[2]*255.,tempvector[3]*255.);
	}
	outlet (2, tempvector);
}