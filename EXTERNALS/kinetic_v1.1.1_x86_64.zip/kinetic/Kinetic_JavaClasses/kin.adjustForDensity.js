/* 
Developed by George Sioros
Licenced under the GPLv3 - Copyright 2009-2017 - INESC-Porto, George Sioros
 */


outlets  = 1;
inlets = 2;
var templateWeights = new Array();
var userWeights = new Array();
var outputWeights = new Array();

var listLen = 0;
var templateSum = 0;
var userSum = 0;
var THRESHOLD = 0.001;


function list()
{
    var i;
    var len = arguments.length;
    if (len <= 0)
        return;
    switch (inlet)
    {
        case 0: //list of user weights
			if (len != listLen)
			{
				//error ("length does not match\n");
				return;
			}

			userSum = 0;
			for ( i = 0 ; i < len ; i++)
			{
				userWeights	[i] =  arguments[i];
				if (userWeights[i]>1.0)
					userWeights[i]=1.0;
				else if (userWeights[i]<0.)
					userWeights[i]= 0;
				userSum += userWeights	[i];
			}
			
			calculateNewWeights();
			outputResult ();			

            break;
        case 1: //list of template weights
            if (len != listLen) //if the length is different than the one previously stored
            {
                createNewArrays();
            }
			templateSum = 0;
            for (i = 0 ; i < len ; i++)
            {
                templateWeights[i] = arguments[i];
				if (templateWeights[i]>1.0)
					templateWeights[i]=1.0;
				else if (templateWeights[i]<0.)
					templateWeights[i]= 0;
				templateSum += templateWeights[i];
            }
            listLen = len;
            break;
    }
}

function createNewArrays()
{
    listLen = 0;
	templateSum = 0;
	userSum = 0;
    templateWeights = new Array();
    userWeights = new Array();
    outputWeights = new Array();

}

createNewArrays.local = 1;


function calculateNewWeights()
{
	var i = 0;
	var iter = 0;
	var j = 0;
	var sumDif = templateSum - userSum;
	var change = new Array();

	while (Math.abs(sumDif) > THRESHOLD && iter < 100)
	{


		j =0;
		if (sumDif >0)
		{
			for (i=0 ; i<listLen ; i++)
			{
				if (userWeights[i]<1.0) 
				{
					j++;
					change[i]=1;
				}else
					change[i]=0;
			}
			
		}else
		{
			for (i=0 ; i<listLen ; i++)
			{
				if (userWeights[i]> 0.) 
				{
					j++;
					change[i]=1;
				}else
					change[i]=0;
			}
		}
		//post ("iter " + iter + " and j = "+ j+"\n");		
		if (j !=0)
		{
			sumDif /= j;
			userSum = 0;
			for (i=0 ; i<listLen ; i++)
			{
				if (change[i])
				{
					userWeights[i] += sumDif;
					if (userWeights[i]>1.0)
						userWeights[i]=1.0;
					else if (userWeights[i]<0.)
						userWeights[i]= 0;	
				}
				userSum += userWeights[i];
			}
			sumDif = templateSum - userSum;
		} else
			sumDif = 0;
		iter++;
	}
	
}
calculateNewWeights.local = 1;


function outputResult ()
{

    outlet(0,userWeights);

}
outputResult.local = 1;