/* 
Developed by George Sioros
Licenced under the GPLv3 - Copyright 2009-2017 - INESC-Porto, George Sioros
 */


outlets  = 2;
inlets = 2;
var templateWeights = new Array();
var userWeights = new Array();
var outputWeights = new Array();
var outputSyncop = new Array();
var listLen = 0;
var THRESHOLD = 0.0000001;


function list()
{
    var i;
    var len = arguments.length;
    if (len <= 0)
        return;
    switch (inlet)
    {
        case 0: //list of user weights
            if (len != listLen)
                return;
            for (i = 0 ; i < len ; i++)
            {
                userWeights[i] = arguments[i];
            }
            caclulateProbabilities();
            outputResult();
            break;
        case 1: //list of template weights
            if (len != listLen) //if the length is different than the one previously stored
            {
                createNewArrays();
            }
            for (i = 0 ; i < len ; i++)
            {
                templateWeights[i] = arguments[i];
            }
            listLen = len;
            break;
    }
}

function createNewArrays()
{
    listLen = 0;
    templateWeights = new Array();
    userWeights = new Array();
    outputWeights = new Array();
    outputSyncop = new Array();
}

createNewArrays.local = 1;

function caclulateProbabilities()
{
   var i, inxt;
   var div = 1;
   var prevDiv = 1; 
   var pdif;
   var count = 0;
   var change = 1;
   var previousTriggers = new Array();
   var temp;
   for (i=0 ; i < listLen ; i++)
   {
       outputWeights[i] = templateWeights[i];
       outputSyncop[i] = 0;
       previousTriggers[i] = outputWeights[i];
   }
   while ( count < 100 && /*change > 0.01 &&*/ div>0.01)// && div<=prevDiv )
       {
           change = 0;
           for (i=0 ; i < listLen ; i++)
           {
               inxt = (i+1)%listLen;
               pdif = outputWeights[i] - outputWeights [inxt];
               temp = outputSyncop[i];
               if (Math.abs(pdif) > THRESHOLD)
                   outputSyncop[i] = (outputWeights[i] - userWeights[i] ) / pdif;
               else
                   outputSyncop[i] = 0;
               if (outputSyncop[i] > 1)
                   outputSyncop[i] = 1;
               else if (outputSyncop[i] < 0)
                   outputSyncop[i] = 0;
               //post ("pulse " + i + "  syncop = " + outputSyncop[i] + "   ");
               change += Math.abs(temp-outputSyncop[i]);

               temp = outputWeights[inxt];
               if (Math.abs(outputSyncop[i]) > THRESHOLD)
                   outputWeights[inxt] = (outputWeights[i]*(outputSyncop[i]-1) + userWeights[i]) /outputSyncop[i];
               if (outputWeights[inxt] >1)
                   outputWeights[inxt]=1;
               else if (outputWeights[inxt] <0)
                   outputWeights[inxt] =0;  
               //post ("  weight (i+1) = " + outputWeights[inxt] + "\n");
               change += Math.abs(temp-outputWeights[inxt]);
           }
           for (i=0; i<listLen ; i++)
           {
               temp =  outputWeights[i];
               inxt = (i+1)%listLen;
               if (Math.abs(outputSyncop[i]-1) > THRESHOLD)
                   outputWeights[i] = (outputWeights[inxt]*outputSyncop[i]-userWeights[i])/(outputSyncop[i]-1);
               if (outputWeights[i] >1)
                   outputWeights[i]=1;
               else if (outputWeights[i] <0)
                   outputWeights[i] =0;
               //post ("pulse " + i + "  weight = " + outputWeights[i] + "\n");

               change += Math.abs(temp-outputWeights[i]);
           }
           prevDiv = div;
           div = 0;
           for (i=0 ; i<listLen ; i++)
           {
               inxt = (i+1)%listLen;
               temp = outputSyncop[i] * outputWeights [inxt] + (1-outputSyncop[i]) * outputWeights[i];
               div += Math.abs( temp - userWeights[i]);
               previousTriggers[i] = temp;
           }
           count++;
           //post ("count = " + count + "   div = "+ div + "\n");
       }
       if (count > 99)
           error ("Did not converge after 100 iterations\n");
       //post("finished iteration -------------- \n");
       //post ("count = " + count + "   div = "+ div + "\n");       
}
caclulateProbabilities.loacal = 1;

function outputResult()
{
    outlet(1,outputSyncop);
    outlet(0,outputWeights);

}

outputResult.local = 1;
